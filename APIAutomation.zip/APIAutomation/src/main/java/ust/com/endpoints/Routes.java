package ust.com.endpoints;


public class Routes {

	public static String baseuri="https://fakerestapi.azurewebsites.net/";
	public static String get_basePath="/api/v1/Books";
	public static String post_basePath="/api/v1/Books";
	public static String getUnique_basePath="/api/v1/Books/{bid}";
	public static String delete_basePath="/api/v1/Books/{bid}";
	public static String update_basePath="/api/v1/Books/{bid}";
	public static String put_basePath="api/v1/Books/3";
	
	
}
