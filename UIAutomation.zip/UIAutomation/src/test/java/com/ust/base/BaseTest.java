package com.ust.base;

import org.aeonbits.owner.ConfigCache;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;

import com.ust.pom.HomePage;

public class BaseTest {	
	
	protected static WebDriver driver;

	ReusableFunctions functions;
	HomePage homePage;
	
	
	@BeforeClass
	public void start() {
		driver=ReusableFunctions.invokeBrowser("BROWSER");
		functions=new ReusableFunctions(driver);
	    functions.openBrowser("BASE_URL");
	    homePage=new HomePage(driver);
	    homePage.closeOffers();
	    
	}
	

//	@AfterClass
//	public void end() {
//		driver.quit();
//	}

}
