package com.ust.test;

import java.util.List;

import org.testng.annotations.Test;

import com.ust.base.BaseTest;
import com.ust.pom.HomePage;
import com.ust.utilities.DataProviders;

public class Search_Test extends BaseTest {
	
	HomePage homePage;
	
	@Test(priority=0 , dataProvider = "product" , dataProviderClass = DataProviders.class)
	public void searchProduct(String product) {
		homePage=new HomePage(driver);
		homePage.SearchProduct(product);
		List<String>products=homePage.addProducts();
		for (String productname : products)
			System.out.println(productname);
	}

}
