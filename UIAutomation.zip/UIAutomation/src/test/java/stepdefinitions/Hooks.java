package stepdefinitions;


import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.ust.base.ReusableFunctions;
import com.ust.pom.HomePage;

import io.cucumber.java.Before;

public class Hooks{

	    public static WebDriver driver;
	    ReusableFunctions functions;
	    private ExtentReports extent;
	    private ExtentTest test;
	    HomePage homePage;
	    int i=0;

	    @Before
	    public void setup(){
	    	driver=functions.invokeBrowser("BROWSER");
	    	ReusableFunctions function = new ReusableFunctions(driver);
	    	function.openBrowser("BASE_URL");
	    	homePage=new HomePage(driver);
		    homePage.closeOffers();

	        //Initialize the Extent reports with the HTML reporter
//	        ExtentSparkReporter reporter = new ExtentSparkReporter("extent.html");
//	        extent = new ExtentReports();
//	        extent.attachReporter(reporter);
//	        //create a new test
//	        test = extent.createTest("Project");
//
//	    }
//	    
//	    
//	    
//	   @After
//	    public void closeBrowser(Scenario scenario) throws InterruptedException, IOException{
//	        if (scenario.isFailed()) {
//	           //Take the screenshot
//	            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);           
//	            File srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
//	    		FileUtils.copyFile(srcFile, new File(System.getProperty("user.dir")+"/screenshots/"+ i++ +".png"));
//	            
//	            
//	            
//	            //Add it to the report
//	            test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
//	        } else {
//	            //Take the screenshot
//	            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
//	            //Add it to the report
//	            test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
//	            test.pass("Test passed");
//	        }
//	        extent.flush();
//	        
//	      // driver.quit();
    }
//


	}

