package stepdefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import com.ust.cucumberpom.ReviewFunctionalityPOM;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ReviewFunctionality {
		WebDriver driver=Hooks.driver;
		ReviewFunctionalityPOM review;
	
	@When("User clicks review stars of the product it scrolls to review part")
	public void user_clicks_review_stars_of_the_product_it_scrolls_to_review_part() {
		review=new ReviewFunctionalityPOM(driver);
	    review.to_review();
	}
	
	@Then("Validate if each review stars are present")
	public void validate_if_each_review_stars_are_present() {
		Boolean star5=review.fivestarreview();
		Boolean star4=review.fourstarreview();
		Boolean star3=review.threestarreview();
		Boolean star2=review.twostarreview();
		Boolean star1=review.onestarreview();
		assertTrue(star5);
		assertTrue(star4);
		assertTrue(star3);
		assertTrue(star2);
		assertTrue(star1);
	}
	@And("Apply filter directly")
	public void apply_filter_directly() {
	    review=new ReviewFunctionalityPOM(driver);
	    review.filtering();
	   
	}

	@And("Check if filter is applied or not")
	public void check_if_filter_is_applied_or_not() {
		 String msg=review.fivestarclick();
	    assertEquals(msg,"5.0 star rating");
	}

	@And("Like and dislike the review posts")
	public void like_and_dislike_the_review_posts() {
	    review=new ReviewFunctionalityPOM(driver);
	    review.likingthereview();
	    review.dislikingthereview();
	}

	@Then("Validate if like is aaplied or not")
	public void validate_if_like_is_aaplied_or_not() {
	    
	}

}
