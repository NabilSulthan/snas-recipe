package classestobedeleted;

import static org.testng.Assert.assertTrue;

import com.ust.base.BaseTest;
import com.ust.base.ReusableFunctions;
import com.ust.pom.HomePage;
import com.ust.pom.LoginPage;

import io.cucumber.java.Before;

/**
 * This class contains the test for login functionality.
 *
 * @author Tabnine
 */
public class LoginTest extends BaseTest {
			HomePage homePage;
			ReusableFunctions functions;
    /**
     * This method tests the login functionality.
     *
     * @throws Exception If any error occurs during the test.
     */
    @Before
    public void checkout() throws Exception {
        // Arrange
    	homePage=new HomePage(driver);
    	functions=new ReusableFunctions(driver);
        LoginPage loginPage = homePage.clickAccount();

        // Act
        loginPage.enterEmail("harrykane@gmail.com");              
        functions.delay(4);
        loginPage.enterPassword("harrykane@123");
        functions.delay(4);
        loginPage.clickSignIn();
        // Assert
        assertTrue(loginPage.logoutPresent(), "Login was successful");
    }
    
    
    
   
}