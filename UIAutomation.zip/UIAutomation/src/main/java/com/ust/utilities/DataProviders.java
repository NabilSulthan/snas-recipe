package com.ust.utilities;

import org.testng.annotations.DataProvider;

public class DataProviders {



    @DataProvider(name="product")
    public Object getProducts() {
        
//		Object[] products= {"hair serum","skin care"};
//		
        return "hair serum";
    }

}
	

