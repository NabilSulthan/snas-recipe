package com.ust.pom;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.base.ReusableFunctions;

public class HomePage {
	ReusableFunctions functions;
	static WebDriver driver;
	
	public HomePage(WebDriver driver) {
        this.driver=driver;
        functions=new ReusableFunctions(driver);
        PageFactory.initElements(driver, this);
    }
	
	@FindBy(xpath="(//button[@class='action-close'])[2]")
	WebElement close;
	@FindBy(css = "label[for='search']")
    WebElement search_icon;
	@FindBy(xpath="(//input[@placeholder='Search The Web Store...'])[2]")
    WebElement search_bar;
	@FindBy(xpath="//a[@class='product-item-link']")
	List<WebElement> products;
	
	List<String> product_names;
	
	public void closeOffers()  {

		functions.clickOn(close, 6);
		
	}	

    public void SearchProduct(String product_name) {
    	functions.clickOn(search_icon, 4);
    	functions.sendText(search_bar, product_name);
    	functions.delay(5);
   }
    
	public List addProducts() {
		
		for(WebElement product : products)
			 product_names.add(product.getText());
	       return product_names;
	}
	
	
	
}