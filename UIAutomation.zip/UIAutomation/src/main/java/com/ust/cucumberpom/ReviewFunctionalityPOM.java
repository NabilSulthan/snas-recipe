package com.ust.cucumberpom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.base.ReusableFunctions;

public class ReviewFunctionalityPOM {
	
	WebDriver driver;
	ReusableFunctions functions;
	
	public ReviewFunctionalityPOM(WebDriver driver) {
		this.driver=driver;
		functions=new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	//locator of review stars of the product
	@FindBy(css="div[data-product-id='1006'][data-yotpo-element-id='2']")
	WebElement reviewstars;
	
	//locator of review star to be asserted
	@FindBy(xpath="(//span[@class='sr-only'])[31]")
	WebElement starvalidate;
	
	//locator of each stars
	@FindBy(xpath="(//div[@class='yotpo-star-distribution-bar-score'])[1]")
	WebElement fivestar;
	@FindBy(xpath="(//div[@class='yotpo-star-distribution-bar-score'])[2]")
	WebElement fourstar;
	@FindBy(xpath="(//div[@class='yotpo-star-distribution-bar-score'])[3]")
	WebElement threestar;
	@FindBy(xpath="(//div[@class='yotpo-star-distribution-bar-score'])[4]")
	WebElement twostar;
	@FindBy(xpath="(//div[@class='yotpo-star-distribution-bar-score'])[5]")
	WebElement onestar;
	
	@FindBy(xpath="(//span[@class='sr-only'])[18]")
	WebElement isfivestar;
	@FindBy(xpath="(//span[@class='yotpo-icon yotpo-icon-down-triangle'])[1]")
	WebElement filterclick;
	@FindBy(css="li[sort-name='5']")
	WebElement option5;
	
	@FindBy(xpath="(//div[@class='yotpo-review-stars '])[2]/span[6]")
	WebElement fivestartext;
//	@FindBy(xpath="(//span[@class='yotpo-icon yotpo-icon-thumbs-up'])[1]")
//	@FindBy(xpath="(//span[@class='yotpo-icon yotpo-icon-thumbs-up'])[2]")
//	WebElement like;
	
	//method for clicking review stars which in turn scroll to review part of the product page
	public void to_review()
	{
		functions.clickOn(reviewstars, 2);
	}
	public boolean fivestarreview()
	{
		return fivestar.isDisplayed();
	}
	public boolean fourstarreview()
	{
		return fourstar.isDisplayed();
	}
	public boolean threestarreview()
	{
		return threestar.isDisplayed();
	}
	public boolean twostarreview()
	{
		return twostar.isDisplayed();
	}
	public boolean onestarreview()
	{
		return onestar.isDisplayed();
	}
	public void filtering()
	{
		functions.delay(2);
		functions.clickOn(filterclick, 2);
		functions.delay(2);
		functions.clickOn(option5, 2);
	}
	public String fivestarclick()
	{
		String fivestarmsg=functions.getTextofElement(fivestartext);
		return fivestarmsg;	
	}
	public void likingthereview()
	{
		functions.delay(2);
		for(int i=2;i<7;i++)
		{
			WebElement like=driver.findElement(By.xpath("(//span[@class='yotpo-icon yotpo-icon-thumbs-up'])"+"["+i+"]"));
			functions.mouseAction(like);
		}
	}
	public void dislikingthereview()
	{
		functions.delay(2);
		for(int i=2;i<7;i++)
		{
			WebElement dislike=driver.findElement(By.xpath("(//span[@class='yotpo-icon yotpo-icon-thumbs-down'])"+"["+i+"]"));
			functions.mouseAction(dislike);
		}
	}
}
